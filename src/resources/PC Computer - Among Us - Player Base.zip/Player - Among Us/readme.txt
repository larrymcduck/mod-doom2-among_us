Sprites ripped by JordanTRS and JJ314 and collinsisyou
JordanTrs's Channel: https://www.youtube.com/channel/UCGMsFdGMBgjm5zYMUohTLvg